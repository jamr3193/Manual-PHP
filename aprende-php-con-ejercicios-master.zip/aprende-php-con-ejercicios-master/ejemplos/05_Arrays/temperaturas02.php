<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
  </head>
  <body>
    <?php
      $temp = array(16, 15, 17, 15, 16);
      echo "La temperatura en Málaga el cuarto día del año fue de ";
      echo $temp[3], "ºC"; 
    ?>
  </body>
</html>
