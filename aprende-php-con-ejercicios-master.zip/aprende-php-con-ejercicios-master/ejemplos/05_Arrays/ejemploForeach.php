<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
  </head>
  <body>
    <?php
      $cajonDeSastre = [30, -7, "Me gusta el queso", 56, "¡eh!", 237];

      foreach ($cajonDeSastre as $cosa) {
        echo "$cosa<br>";
      }
    ?>
  </body>
</html>
