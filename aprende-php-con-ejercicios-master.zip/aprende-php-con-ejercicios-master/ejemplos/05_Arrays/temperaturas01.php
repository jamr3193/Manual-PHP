<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
  </head>
  <body>
    <?php 
      $temp[0] = 16;
      $temp[1] = 15;
      $temp[2] = 17;
      $temp[3] = 15;
      $temp[4] = 16;
      echo "La temperatura en Málaga el cuarto día del año fue de ";
      echo $temp[3], "ºC";
    ?>
  </body>
</html>
