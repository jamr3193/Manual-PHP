<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
  </head>
  <body>
    <?php
      $estatura = array("Rosa" => 168, "Ignacio" => 175, "Daniel" => 172, "Rubén" => 182);
      echo "La estatura de Daniel es ", $estatura['Daniel'] , " cm"; 
    ?>
  </body>
</html>