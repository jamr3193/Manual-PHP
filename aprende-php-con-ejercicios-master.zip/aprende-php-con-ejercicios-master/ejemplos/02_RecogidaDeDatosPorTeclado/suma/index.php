<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
  </head>
  <body>
    <h3>Calcula la suma de dos números</h3>
    <form action="suma.php" method="get">
    Primer número: <input type="number" name="a"><br>
    Segundo número: <input type="number" name="b"><br>
    <input type="submit" value="Sumar">
    </form>
  </body>
</html>
