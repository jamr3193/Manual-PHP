<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
  </head>
  <body>
    <?php
      $a = $_GET['a'];
      $b = $_GET['b'];
      echo "La suma de $a mas $b es ", $a + $b;
    ?>
  </body>
</html>
