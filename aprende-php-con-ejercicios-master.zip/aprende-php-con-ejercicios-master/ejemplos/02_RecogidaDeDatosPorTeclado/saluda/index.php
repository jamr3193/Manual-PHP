<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
  </head>
  <body>
    Introduce tu nombre:
    <form action="saluda.php" method="get">
    <input type="text" name="nombre"><br>
    <input type="submit" value="Enviar">
    </form>
  </body>
</html>
