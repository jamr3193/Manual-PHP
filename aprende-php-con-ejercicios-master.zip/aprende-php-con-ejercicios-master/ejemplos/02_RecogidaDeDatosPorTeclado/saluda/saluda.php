<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
  </head>
  <body>
    Hola <?= $_GET['nombre'] ?>,
    que tengas un buen día.
  </body>
</html>
