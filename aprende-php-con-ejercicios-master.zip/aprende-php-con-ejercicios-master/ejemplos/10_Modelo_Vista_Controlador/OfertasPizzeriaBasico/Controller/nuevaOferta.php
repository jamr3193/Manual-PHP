<?php
  // Carga la vista del formulario de alta de oferta
  include '../View/formularioOferta.php';
