<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title></title>
  </head>
  <body>
    <?php
      $a = 5;
      $b = "5";
      echo ($a == 5) ? "verdadero" : "falso", "<br>";
      echo ($a === 5) ? "verdadero" : "falso", "<br>";
      echo ($b == 5) ? "verdadero" : "falso", "<br>";
      echo ($b === 5) ? "verdadero" : "falso", "<br>";
    ?>
  </body>
</html>
