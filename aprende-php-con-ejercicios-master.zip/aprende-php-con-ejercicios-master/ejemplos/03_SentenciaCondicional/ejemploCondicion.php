<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
  </head>
  <body>
    <?php
      $a = 8; 
      $b = 3;
      if ($a < $b) {
        echo "a es menor que b"; 
      } else { 
        echo "a no es menor que b"; 
      }
    ?>
  </body>
</html>
