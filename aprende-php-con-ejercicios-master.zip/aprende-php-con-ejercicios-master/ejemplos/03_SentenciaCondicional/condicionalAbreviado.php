<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title></title>
  </head>
  <body>
    <?php
      $x = (20 > 6) ? 11 : 22;
      echo $x;
    ?>
  </body>
</html>
