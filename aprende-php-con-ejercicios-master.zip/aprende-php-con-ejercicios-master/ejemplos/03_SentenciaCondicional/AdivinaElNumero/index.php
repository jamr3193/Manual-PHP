<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
  </head>
  <body>
    Adivina el número que estoy pensando.
    <form action="adivina.php" method="post">
      <input type="hidden" name="numeroIntroducido" value="555">
      <input type="hidden" name="oportunidades" value="5">
      <input type="submit" value="Continuar">
    </form>
  </body>
</html>
