<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
  </head>
  <body>
    <?php
      $i = 0;
      while( $i < 10 ) {
        echo "El valor de i es ", $i,"<br>"; $i++;
      }
    ?>
  </body>
</html>
