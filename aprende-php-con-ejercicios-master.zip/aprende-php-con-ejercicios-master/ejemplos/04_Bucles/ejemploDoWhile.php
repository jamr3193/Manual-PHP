<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
  </head>
  <body>
    <?php
    $i = 0;
    do {
      echo "El valor de i es ", $i,"<br>"; $i++;
    } while( $i < 10 )
    ?>
  </body>
</html>
