<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
  </head>
  <body>
    <?php
      for($i = 0 ; $i < 10 ; $i++) {
        echo "El valor de i es ", $i,"<br>";
      }
    ?>
  </body>
</html>
