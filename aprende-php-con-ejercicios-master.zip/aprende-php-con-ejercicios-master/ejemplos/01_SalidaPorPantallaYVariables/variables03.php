<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
  </head>
  <body>
    <?php
      $numero = 20;
      $palabra = "hola";
      print_r(get_defined_vars());
    ?>
  </body>
</html>
