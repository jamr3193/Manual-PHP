<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
  </head>
  <body>
    <!-- Muestra una frase con HTML -->
    Hola mundo<br>
    <!-- Muestra una frase con PHP -->
    <?php echo "Es muy fácil programar en PHP."; ?>
  </body>
</html>
