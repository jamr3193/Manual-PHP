<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
  </head>
  <body>
    <!-- Utilizo PHP para poner en negrita una palabra -->
    Hola
    <?php echo "<b><u>"; ?>
    mundo
    <?php echo "</u></b>"; ?>
  </body>
</html>
