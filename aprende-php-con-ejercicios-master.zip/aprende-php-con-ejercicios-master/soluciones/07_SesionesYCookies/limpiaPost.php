<?php
  session_start();
  header("Location: ".$_SESSION['pagina']);

