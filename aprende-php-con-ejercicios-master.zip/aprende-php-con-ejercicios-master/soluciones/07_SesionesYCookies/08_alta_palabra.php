<h3>Nueva palabra</h3><hr>
<form action="pagina.php" method="post">
  <input type="hidden" name="ejercicio" value="08_admin_palabras">
  Español: <input type="text" name="espanol" autofocus=""><br>
  Inglés: <input type="text" name="ingles"><br>
  <input type="submit" name="accion" value="Alta">
</form>
<br><br>