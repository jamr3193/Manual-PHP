<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <link href="default.css" rel="stylesheet" type="text/css" />
  </head>
  <body>
    <div id="container">
      <div id="header">
        <h1>
          APRENDE PHP CON EJERCICIOS
        </h1>
        <h2>
          SOLUCIONES A LOS EJERCICIOS
        </h2>
        <h2>
          <br>3. Sentencia condicional
        </h2>
      </div>

      <div id="content">
        Este programa ordena tres números.<br>
        <form action="13result.php" method="post">
          Número 1 <input type="number" name="a"><br>
          Número 2 <input type="number" name="b"><br>
          Número 3 <input type="number" name="c"><br>
          <input type="submit" value="Aceptar">
        </form>
      </div>
      
      <div id="footer">
        © Luis José Sánchez González
      </div>
      
    </div>
  </body>
</html>
