# APRENDE PHP CON EJERCICIOS

Ejemplos y soluciones a los ejercicios del libro ***"Aprende PHP con Ejercicios"***.

Puedes descargar el libro mediante el siguiente enlace:
<http://leanpub.com/aprendephpconejercicios>
